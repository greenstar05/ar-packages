---
uid: arfoundation-simulation-features
---
# Features

You can currently test the following AR features using XR Simulation:

[!include[](../snippets/simulation-features-table.md)]
