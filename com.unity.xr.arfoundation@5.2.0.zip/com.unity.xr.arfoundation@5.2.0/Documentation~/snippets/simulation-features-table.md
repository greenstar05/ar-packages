| Feature                                                                    | Supported |
| :--------------------------------------------------------------------------|:---------:|
| [Session](xref:arfoundation-session)                                       |    Yes    |
| [Device tracking](xref:arfoundation-device-tracking)                       |    Yes    |
| [Camera](xref:arfoundation-simulation-camera)                              |    Yes    |
| [Plane detection](xref:arfoundation-plane-detection)                       |    Yes    |
| [Image tracking](xref:arfoundation-image-tracking)                         |    Yes    |
| [Object tracking](xref:arfoundation-object-tracking)                       |           |
| [Face tracking](xref:arfoundation-face-tracking)                           |           |
| [Body tracking](xref:arfoundation-body-tracking)                           |           |
| [Point clouds](xref:arfoundation-point-clouds)                             |    Yes    |
| [Raycasts](xref:arfoundation-raycasts)                                     |    Yes    |
| [Anchors](xref:arfoundation-anchors)                                       |    Yes    |
| [Meshing](xref:arfoundation-meshing)                                       |    Yes    |
| [Environment Probes](xref:arfoundation-environment-probes)                 |    Yes    |
| [Occlusion](xref:arfoundation-simulation-occlusion)                        |           |
| [Participants](xref:arfoundation-participant-tracking)                     |           |
