> [!NOTE]
> This example code assumes that your app has already initialized XR.
>
> By default XR initializes automatically when your app starts, but this is configurable via **Project Settings** > **XR Plug-in Management** > **Initialize XR on Startup**. Refer to the XR Plug-in Management [End-user documentation](https://docs.unity3d.com/Packages/com.unity.xr.management@latest?subfolder=/manual/EndUser.html) for more detailed information about managing the XR Plug-in lifecycle.