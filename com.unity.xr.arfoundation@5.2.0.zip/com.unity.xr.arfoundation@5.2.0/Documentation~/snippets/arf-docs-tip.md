> [!TIP]
> When developing an AR app, refer to both the AR Foundation documentation as well as the [required packages](xref:arfoundation-manual#required-packages) for each platform you support.
