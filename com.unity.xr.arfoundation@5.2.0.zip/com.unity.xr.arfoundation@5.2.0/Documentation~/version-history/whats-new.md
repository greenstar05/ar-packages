---
uid: arfoundation-whats-new
---
# What's new in version 5.2

The most significant updates in this release include:

For a full list of changes and updates in this version, see the [AR Foundation package changelog](xref:arfoundation-changelog).
