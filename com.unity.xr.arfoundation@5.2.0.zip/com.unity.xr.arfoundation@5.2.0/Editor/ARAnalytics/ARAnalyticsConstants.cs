namespace UnityEditor.XR.ARAnalytics
{
    static class ARAnalyticsConstants
    {
        public const string arFoundationVendorKey = "unity.arfoundation";
        public const int defaultVersion = 1;
    }
}
