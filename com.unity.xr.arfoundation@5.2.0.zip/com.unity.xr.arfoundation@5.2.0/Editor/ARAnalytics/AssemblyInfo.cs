using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.XR.ARFoundation.Editor")]
[assembly: InternalsVisibleTo("Unity.XR.Simulation.Editor")]
