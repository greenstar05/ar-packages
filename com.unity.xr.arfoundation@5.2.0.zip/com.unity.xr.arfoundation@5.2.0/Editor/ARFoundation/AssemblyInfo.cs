using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.XR.ARFoundation.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.XR.Simulation.Runtime.Tests")]
