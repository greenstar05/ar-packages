using System.Runtime.CompilerServices;

#if UNITY_EDITOR
[assembly: InternalsVisibleTo("Unity.XR.ARSubsystems.Editor")]
[assembly: InternalsVisibleTo("Unity.XR.ARSubsystems.Editor.Tests")]
#endif
