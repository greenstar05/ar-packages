namespace UnityEngine.XR.Simulation
{
    internal interface ISimulationSessionResetHandler
    {
        // ReSharper disable once UnusedMemberInSuper.Global
        void OnSimulationSessionReset();
    }
}
