namespace UnityEngine.XR.ARKit
{
    enum NSStringEncoding : ulong
    {
        NSUTF16LittleEndianStringEncoding = 0x94000100
    }
}
