namespace UnityEngine.XR.ARKit
{
    static class Constants
    {
        public const string k_LoaderDisabledExceptionMsg = "Apple ARKit XR Plug-in Provider not enabled in project settings.";
    }
}
