namespace UnityEngine.XR.ARKit
{
    static class ARKitPackageInfo
    {
        public const string displayName = "Apple ARKit XR Plug-in";
        public const string identifier = "com.unity.xr.arkit";
    }
}
