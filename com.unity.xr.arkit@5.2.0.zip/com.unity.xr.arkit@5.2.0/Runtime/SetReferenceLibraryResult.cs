namespace UnityEngine.XR.ARKit
{
    internal enum SetReferenceLibraryResult : int
    {
        Success,
        FeatureUnavailable,
        ResourceDoesNotExist
    }
}
