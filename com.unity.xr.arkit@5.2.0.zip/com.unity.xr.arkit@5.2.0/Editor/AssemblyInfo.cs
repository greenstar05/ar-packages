using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.XR.ARKit.Editor.Tests")]
